#include <Engine/PCH.h>
#include <Engine/Application/Application.h>
#include <Engine/Core/FileSystem.h>
#include <Engine/Core/VFS.h>
#include <Engine/Core/Profiler/EngineProfiler.h>

#include "Events/ApplicationEvent.h"
#include "Events/EventDispatcher.h"
#include "Events/KeyEvent.h"
#include "Events/MouseEvent.h"
#include "Input/Input.h"
#include "Rendering/GLRenderingAPI.h"

namespace SIMPEngine
{
    class KeyReleasedEvent;
    class KeyPressedEvent;
    class WindowCloseEvent;
    Application *Application::s_Instance = nullptr;

    Application::Application()
    {

        s_Instance = this;
        m_Window.Init("SIMPEngine", 1920, 1080);

        int w, h;
        SDL_GetWindowSize(m_Window.GetNativeWindow(), &w, &h);
        Renderer::Init(std::make_unique<GLRenderingAPI>(), w, h);

        auto imguiLayer = std::make_unique<ImGuiLayer>();

        m_ImGuiLayer = imguiLayer.get();

        PushOverlay(std::move(imguiLayer));

        CORE_INFO("Entt version {}", ENTT_VERSION);
    }

    Application::~Application()
    {
        ImGui::SaveIniSettingsToDisk(ImGui::GetIO().IniFilename);
        // The window (and its GL context) is shut down by m_Window's own destructor,
        // which runs after m_LayerStack has been destroyed, so layers can still
        // free their GL resources.
        s_Instance = nullptr;
    }

    void Application::Run()
    {
        Input::ResetAllKeys();

        uint64_t lastFrameTime = SDL_GetPerformanceCounter();
        const double freq = (double)SDL_GetPerformanceFrequency();

        // actual gameloop
        while (m_Running)
        {
            PROFILE_FRAME_BEGIN();

            uint64_t currentFrameTime = SDL_GetPerformanceCounter();
            float deltaTime = (float)((currentFrameTime - lastFrameTime) / (float)freq);
            lastFrameTime = currentFrameTime;

            {
                PROFILE_SCOPE("Events");

                SDL_Event sdlEvent;
                while (SDL_PollEvent(&sdlEvent))
                {
                    if (m_ImGuiLayer)
                        m_ImGuiLayer->OnSDLEvent(sdlEvent); // LOOKAT
                    SDLEventToEngine(sdlEvent);
                }
            }

            // update all layers
            {
                PROFILE_SCOPE("LayerUpdate");

                for (auto & layer : m_LayerStack)
                    layer->OnUpdate(TimeStep(deltaTime));
            }

            // Rendering
            {
                {
                    PROFILE_SCOPE("Render/SetClearColor");
                    Renderer::SetClearColor(0.329f,
                                            0.329f,
                                            0.329f,
                                            1.0f);
                }
                {
                    PROFILE_SCOPE("Render/ClearCall");
                    Renderer::Clear();
                }
                {
                    PROFILE_SCOPE("Render/ImGuiBegin");
                    m_ImGuiLayer->Begin();
                }
                {
                    PROFILE_SCOPE("Render/Layers");
                    for (auto & layer : m_LayerStack)
                        layer->OnRender();
                }

                // #ifdef NO_EDITOR
                // EngineProfiler::Profiler::Get().DrawImGui();
                // #endif

                {
                    PROFILE_SCOPE("Render/ImGuiEnd");
                    m_ImGuiLayer->End();
                }
            }

            // Renderer::Present();
            // SDL_GL_SwapWindow(m_Window.GetNativeWindow());
            {
                PROFILE_SCOPE("Render/Swap");
                m_Window.OnUpdate();
            }
            PROFILE_FRAME_END();
        }
    }

    void Application::PushLayer(std::unique_ptr<Layer> layer)
    {
        m_LayerStack.PushLayer(std::move(layer));
    }

    void Application::PushOverlay(std::unique_ptr<Layer> overlay)
    {
        m_LayerStack.PushOverlay(std::move(overlay));
    }

    void Application::SDLEventToEngine(SDL_Event &sdlEvent)
    {
        switch (sdlEvent.type)
        {
        case SDL_EVENT_QUIT:
        {
            WindowCloseEvent e;
            OnEvent(e);
            break;
        }
        case SDL_EVENT_WINDOW_RESIZED:
        {
            WindowResizeEvent e(sdlEvent.window.data1, sdlEvent.window.data2);
            OnEvent(e);
            break;
        }
        case SDL_EVENT_KEY_DOWN:
        {
            bool repeat = (sdlEvent.key.repeat != 0);
            KeyPressedEvent e(sdlEvent.key.key, repeat);
            OnEvent(e);
            break;
        }
        case SDL_EVENT_KEY_UP:
        {
            KeyReleasedEvent e(sdlEvent.key.key);
            OnEvent(e);
            break;
        }
        case SDL_EVENT_TEXT_INPUT:
        {
            KeyTypedEvent e(sdlEvent.text.text[0]); // first char for simplicity
            OnEvent(e);
            break;
        }
        case SDL_EVENT_MOUSE_MOTION:
        {
            MouseMovedEvent e(sdlEvent.motion.x, sdlEvent.motion.y);
            OnEvent(e);
            break;
        }
        case SDL_EVENT_MOUSE_BUTTON_DOWN:
        {
            MouseButtonPressedEvent e(sdlEvent.button.button);
            OnEvent(e);
            break;
        }
        case SDL_EVENT_MOUSE_BUTTON_UP:
        {
            MouseButtonReleasedEvent e(sdlEvent.button.button);
            OnEvent(e);
            break;
        }
        case SDL_EVENT_MOUSE_WHEEL:
        {
            MouseScrolledEvent e(sdlEvent.wheel.x, sdlEvent.wheel.y);
            OnEvent(e);
            break;
        }
        default:
            break;
        }
    }

    void Application::OnEvent(Event &e)
    {
        m_ImGuiLayer->OnEvent(e);

        EventDispatcher dispatcher(e);

        dispatcher.Dispatch<WindowCloseEvent>([this](WindowCloseEvent &ev)
                                              {
        m_Running = false;
        return true; });

        dispatcher.Dispatch<KeyPressedEvent>([](KeyPressedEvent &ev)
                                             {
                                                //  CORE_INFO("KeyPressedEvent keycode = {}", ev.GetKeyCode());
                                                 Input::OnKeyPressed(ev.GetKeyCode());
                                                 return false; });

        dispatcher.Dispatch<KeyReleasedEvent>([](KeyReleasedEvent &ev)
                                              {
                                                //  CORE_INFO("{}", ev.ToString());

        Input::OnKeyReleased(ev.GetKeyCode());
        return false; });

        dispatcher.Dispatch<MouseButtonPressedEvent>([](MouseButtonPressedEvent &ev)
                                                     {
                                                //  CORE_INFO("{}", ev.ToString());

        Input::OnMouseButtonPressed(ev.GetMouseButton());
        return false; });

        dispatcher.Dispatch<MouseButtonReleasedEvent>([](MouseButtonReleasedEvent &ev)
                                                      {

                                                //  CORE_INFO("{}", ev.ToString());

        Input::OnMouseButtonReleased(ev.GetMouseButton());
        return false; });

        dispatcher.Dispatch<MouseMovedEvent>([](MouseMovedEvent &ev)
                                             {

                                                //  CORE_INFO("{}", ev.ToString());

        Input::OnMouseMoved(ev.GetX(), ev.GetY());
        return false; });

        dispatcher.Dispatch<MouseScrolledEvent>([](MouseScrolledEvent &ev)
                                                {
    // CORE_INFO("Mouse wheel delta: {}", ev.GetYOffset());
    Input::OnMouseWheel(ev.GetYOffset());
    return false; });

        if (!e.Handled)
        {
            for (auto it = m_LayerStack.end(); it != m_LayerStack.begin();)
            {
                (*--it)->OnEvent(e);
                if (e.Handled)
                    break;
            }
        }
    }
}
